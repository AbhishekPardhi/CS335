public class ExampleExpression {
    
    public static void main(String[] args) {
      int arr[] = new int[6];
      arr[2] = 3;
      println(arr[2]);
    }
  }