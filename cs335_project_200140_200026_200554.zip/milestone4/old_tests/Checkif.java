public class Checkif {
    public void main(String[] args) {
        int x = 3;
        if (x + 2 == 5) {
            x = 10;
        }
        else {
            x = 20;
        }
        println(x);
    }
}
