<!-- For statements -->
<!-- (lite) Function invocations -->
<!-- Expressions -->
<!-- (lite) Method declarations -->
<!-- Quadruples -->
<!-- FieldAccess -->
<!-- (lite) Number of bytes for offset -->
<!-- CLASSSSS -->
<!-- (lite) print statements -->
break(done), continue(remaining)
<!-- Get offset for qulaified name -->
for arr[2]=4 => Check if arrayBase exists, then set $->arrayBase[$->addr] to be the address

- Features to flex
- [] Function call - QualifiedName
- [] Function call - Parameters
- [] Instance creation using offset
- [] Field Access using offset

Wow:
ArrayAccess->ArrayAccess(was initially PrimaryNoNewArray) LSPAR Expression RSPAR